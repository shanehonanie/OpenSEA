#include "hydrodynamicinput.h"


HydrodynamicInput::HydrodynamicInput() : ReadInput()
{
}


HydrodynamicInput::~HydrodynamicInput()
{
}

void HydrodynamicInput::setData(istream& infile)
{

}

void HydrodynamicInput::initializeDefaults()
{

}

int HydrodynamicInput::legalKeyword(string stringIn)
{
	return 0;
}
