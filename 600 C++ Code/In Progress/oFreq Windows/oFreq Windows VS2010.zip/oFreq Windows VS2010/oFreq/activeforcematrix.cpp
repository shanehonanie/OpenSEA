#include "activeforcematrix.h"


ActiveForceMatrix::ActiveForceMatrix()
{
}


ActiveForceMatrix::~ActiveForceMatrix()
{
}
