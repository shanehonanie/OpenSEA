var searchData=
[
  ['orderderivative',['orderDerivative',['../class_global_solution.html#a026746ffb8e416eb4142a058b108148c',1,'GlobalSolution']]]
];
